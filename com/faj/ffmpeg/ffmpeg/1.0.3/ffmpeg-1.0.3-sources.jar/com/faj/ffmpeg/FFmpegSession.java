package com.faj.ffmpeg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Represents one invocation of FFmpeg. Created via {@link FFmpegKit#execute},
 * {@link FFmpegKit#executeAsync}, or {@link FFmpegKit#executeWithArguments}.
 *
 * <p>A session captures the command line, the {@link ReturnCode}, every
 * {@link Log} line emitted by FFmpeg, and the most recent {@link Statistics}
 * sample. Sessions are kept in memory by {@link FFmpegKitConfig} until
 * {@link FFmpegKitConfig#clearSessions()} is called.</p>
 */
public final class FFmpegSession {

    /** Process-wide unique session id. */
    private static final AtomicLong SEQ = new AtomicLong(1);

    public enum State { CREATED, RUNNING, FAILED, COMPLETED }

    private final long sessionId;
    private final String[] arguments;
    private final Date createTime;
    private volatile Date startTime;
    private volatile Date endTime;
    private volatile State state;
    private volatile ReturnCode returnCode;
    private volatile Throwable failStackTrace;
    private volatile Statistics lastStatistics;

    private final List<Log> logs = Collections.synchronizedList(new ArrayList<>());

    final LogCallback logCallback;
    final StatisticsCallback statisticsCallback;
    final SessionCallback completeCallback;

    FFmpegSession(String[] arguments,
                  LogCallback logCallback,
                  StatisticsCallback statisticsCallback,
                  SessionCallback completeCallback) {
        this.sessionId = SEQ.getAndIncrement();
        this.arguments = arguments == null ? new String[0] : arguments.clone();
        this.createTime = new Date();
        this.state = State.CREATED;
        this.logCallback = logCallback;
        this.statisticsCallback = statisticsCallback;
        this.completeCallback = completeCallback;
    }

    public long getSessionId() { return sessionId; }
    public String[] getArguments() { return arguments.clone(); }

    public String getCommand() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arguments.length; i++) {
            if (i > 0) sb.append(' ');
            // Quote arguments that contain spaces.
            String a = arguments[i];
            if (a.indexOf(' ') >= 0) sb.append('"').append(a).append('"');
            else sb.append(a);
        }
        return sb.toString();
    }

    public Date  getCreateTime() { return createTime; }
    public Date  getStartTime()  { return startTime; }
    public Date  getEndTime()    { return endTime; }
    public State getState()      { return state; }
    public ReturnCode getReturnCode() { return returnCode; }
    public Throwable  getFailStackTrace() { return failStackTrace; }
    public Statistics getLastStatistics() { return lastStatistics; }

    /** @return milliseconds between start and end, or -1 if not finished. */
    public long getDuration() {
        if (startTime == null || endTime == null) return -1;
        return endTime.getTime() - startTime.getTime();
    }

    /** Snapshot of all logs received so far. */
    public List<Log> getLogs() {
        synchronized (logs) { return new ArrayList<>(logs); }
    }

    /** Concatenated log output. Convenient for displaying / debugging. */
    public String getAllLogsAsString() {
        StringBuilder sb = new StringBuilder();
        synchronized (logs) {
            for (Log l : logs) sb.append(l.getMessage());
        }
        return sb.toString();
    }

    // ---- internal mutators (called by FFmpegKitConfig) --------------------

    void onStart() {
        startTime = new Date();
        state = State.RUNNING;
    }

    void onComplete(int code) {
        endTime = new Date();
        returnCode = new ReturnCode(code);
        state = State.COMPLETED;
    }

    void onFail(Throwable t) {
        endTime = new Date();
        failStackTrace = t;
        state = State.FAILED;
    }

    void appendLog(Log log) {
        logs.add(log);
    }

    void updateStatistics(Statistics s) {
        lastStatistics = s;
    }

    @Override
    public String toString() {
        return "FFmpegSession{id=" + sessionId
            + ", state=" + state
            + ", returnCode=" + returnCode
            + ", args=" + Arrays.toString(arguments) + "}";
    }
}
