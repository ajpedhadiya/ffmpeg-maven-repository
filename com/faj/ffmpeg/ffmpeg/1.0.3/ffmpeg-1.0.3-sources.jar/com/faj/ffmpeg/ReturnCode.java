package com.faj.ffmpeg;

/**
 * Mirrors POSIX-style return codes used by the FFmpeg CLI.
 * 0 indicates success; non-zero values are FFmpeg's negative {@code AVERROR}
 * codes converted to positive ints, except {@link #CANCEL} which is reserved.
 */
public final class ReturnCode {

    public static final int SUCCESS = 0;
    public static final int CANCEL = 255;

    private final int value;

    public ReturnCode(int value) {
        this.value = value;
    }

    public int getValue() { return value; }

    public boolean isValueSuccess() { return value == SUCCESS; }
    public boolean isValueError()   { return value != SUCCESS && value != CANCEL; }
    public boolean isValueCancel()  { return value == CANCEL; }

    @Override public String toString() { return Integer.toString(value); }
}
