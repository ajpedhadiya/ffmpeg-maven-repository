package com.faj.ffmpeg;

/**
 * Periodic progress report emitted by FFmpeg during transcoding (mirrors the
 * fields ffmpeg writes to its {@code -progress} stream).
 */
public final class Statistics {
    private final long sessionId;
    private final int videoFrameNumber;
    private final float videoFps;
    private final float videoQuality;
    private final long size;
    private final int time;          // milliseconds
    private final double bitrate;    // kbits/s
    private final double speed;      // multiplier (1.0 = realtime)

    public Statistics(long sessionId, int videoFrameNumber, float videoFps,
                      float videoQuality, long size, int time,
                      double bitrate, double speed) {
        this.sessionId = sessionId;
        this.videoFrameNumber = videoFrameNumber;
        this.videoFps = videoFps;
        this.videoQuality = videoQuality;
        this.size = size;
        this.time = time;
        this.bitrate = bitrate;
        this.speed = speed;
    }

    public long getSessionId()       { return sessionId; }
    public int  getVideoFrameNumber(){ return videoFrameNumber; }
    public float getVideoFps()       { return videoFps; }
    public float getVideoQuality()   { return videoQuality; }
    public long  getSize()           { return size; }
    public int   getTime()           { return time; }
    public double getBitrate()       { return bitrate; }
    public double getSpeed()         { return speed; }
}
