package com.faj.ffmpeg;

/** Functional interface invoked for every log line FFmpeg produces. */
public interface LogCallback {
    void apply(Log log);
}
