package com.faj.ffmpeg;

import java.util.concurrent.Future;

/**
 * Public facade. Mirrors the most-used surface of
 * {@code com.arthenica.ffmpegkit.FFmpegKit}.
 *
 * <p>Synchronous variants block the caller until FFmpeg finishes; async
 * variants return immediately and run on a shared cached thread pool.</p>
 */
public final class FFmpegKit {

    private static volatile boolean sLoaded = false;

    private FFmpegKit() {}

    /** Loads every native library. Safe to call repeatedly. */
    public static synchronized void load() {
        if (sLoaded) return;
        // Dependency order matters.
        try { System.loadLibrary("c++_shared"); } catch (UnsatisfiedLinkError ignored) {}
        System.loadLibrary("avutil");
        System.loadLibrary("swresample");
        System.loadLibrary("swscale");
        System.loadLibrary("postproc");
        System.loadLibrary("avcodec");
        System.loadLibrary("avformat");
        System.loadLibrary("avfilter");
        System.loadLibrary("avdevice");
        System.loadLibrary("ffmpegkit_fftools");
        System.loadLibrary("ffmpegkit");
        sLoaded = true;
    }

    public static String getFFmpegVersion() {
        load();
        return nativeGetFFmpegVersion();
    }

    public static String getBuildConfiguration() {
        load();
        return nativeGetBuildConfiguration();
    }

    /**
     * Run an ffmpeg-style command line synchronously. Whitespace splits the
     * command; arguments containing spaces should use the
     * {@link #executeWithArguments(String[])} overload to avoid surprises.
     *
     * @return the resulting {@link FFmpegSession}; check
     *         {@link FFmpegSession#getReturnCode()} for success.
     */
    public static FFmpegSession execute(String command) {
        return executeWithArguments(splitCommand(command));
    }

    public static FFmpegSession executeWithArguments(String[] arguments) {
        FFmpegLicense.check();
        load();
        FFmpegSession session = new FFmpegSession(arguments, null, null, null);
        FFmpegKitConfig.runSession(session);
        return session;
    }

    /** Async variant; returns immediately. The session is updated when done. */
    public static FFmpegSession executeAsync(String command, SessionCallback onComplete) {
        return executeWithArgumentsAsync(splitCommand(command), null, null, onComplete);
    }

    /**
     * Async overload that takes only a completion callback — matches the
     * most common arthenica-style call site:
     * <pre>{@code FFmpegKit.executeWithArgumentsAsync(args) { session -> ... }}</pre>
     * Log / statistics callbacks (if needed) should be registered globally
     * via {@link FFmpegKitConfig#enableLogCallback(LogCallback)} /
     * {@link FFmpegKitConfig#enableStatisticsCallback(StatisticsCallback)}.
     */
    public static FFmpegSession executeWithArgumentsAsync(String[] arguments,
                                                           SessionCallback onComplete) {
        return executeWithArgumentsAsync(arguments, null, null, onComplete);
    }

    public static FFmpegSession executeWithArgumentsAsync(String[] arguments,
                                                           LogCallback logCallback,
                                                           StatisticsCallback statsCallback,
                                                           SessionCallback completeCallback) {
        FFmpegLicense.check();
        load();
        FFmpegSession session = new FFmpegSession(arguments, logCallback, statsCallback, completeCallback);
        FFmpegKitConfig.registerSession(session);
        Future<?> ignored = FFmpegKitConfig.asyncExecutor().submit(() -> FFmpegKitConfig.runSession(session));
        return session;
    }

    /** Cancel a running session by id. No-op if the session isn't running. */
    public static void cancel(long sessionId) {
        load();
        FFmpegKitConfig.nativeFFmpegCancel(sessionId);
    }

    /** Cancel every running session. */
    public static void cancel() {
        cancel(0L);
    }

    // ---- helpers --------------------------------------------------------

    /**
     * Lightweight command splitter. Recognizes single- and double-quoted
     * substrings; does not interpret backslash escapes.
     */
    static String[] splitCommand(String command) {
        if (command == null || command.isEmpty()) return new String[0];
        java.util.List<String> out = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        char quote = 0;
        for (int i = 0; i < command.length(); i++) {
            char c = command.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0;
                else cur.append(c);
            } else if (c == '"' || c == '\'') {
                quote = c;
            } else if (Character.isWhitespace(c)) {
                if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            } else {
                cur.append(c);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out.toArray(new String[0]);
    }

    // ---- native --------------------------------------------------------

    private static native String nativeGetFFmpegVersion();
    private static native String nativeGetBuildConfiguration();
}
