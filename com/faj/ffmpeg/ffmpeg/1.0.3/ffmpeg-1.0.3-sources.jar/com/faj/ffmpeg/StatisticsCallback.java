package com.faj.ffmpeg;

/** Functional interface invoked for every progress report. */
public interface StatisticsCallback {
    void apply(Statistics statistics);
}
