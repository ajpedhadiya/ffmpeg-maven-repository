package com.faj.ffmpeg;

/** Invoked once when a session finishes (success, error, or cancel). */
public interface SessionCallback {
    void apply(FFmpegSession session);
}
