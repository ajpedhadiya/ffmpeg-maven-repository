package com.faj.ffmpeg;

import android.content.Context;

import java.util.Arrays;
import java.util.List;

/**
 * Internal package-name gate for the FFmpeg facade. <b>Not part of the
 * public API</b> — consumers should call
 * {@link FFmpegRemoteLicense#authorize(android.content.Context)} instead,
 * which delegates here as the offline fallback.
 *
 * <p>To add or remove an allowed package, edit {@link #ALLOWED_PACKAGES}
 * and rebuild the AAR.</p>
 */
final class FFmpegLicense {

    // ------------------------------------------------------------------
    // Hardcoded allow-list. Edit this and rebuild the AAR to change it.
    // ------------------------------------------------------------------
    private static final List<String> ALLOWED_PACKAGES = Arrays.asList(
            "com.softek.fffmpegtest",   // internal test app
            "com.pik.roxstar"           // rockstar-live-android
    );

    private static volatile boolean sAuthorized = false;
    private static volatile String sReason = "FFmpegLicense.authorize(context) was never called";

    private FFmpegLicense() {}

    /**
     * Verify the host app is on the hardcoded allow-list.
     * Package-private — called by {@link FFmpegRemoteLicense} as a fallback.
     */
    static synchronized boolean authorize(Context context) {
        if (context == null) {
            sReason = "null Context";
            sAuthorized = false;
            return false;
        }
        String pkg = context.getPackageName();
        if (!ALLOWED_PACKAGES.contains(pkg)) {
            sReason = "package '" + pkg + "' is not licensed to use com.faj.ffmpeg";
            sAuthorized = false;
            return false;
        }
        sReason = null;
        sAuthorized = true;
        return true;
    }

    /** True once {@link #authorize(Context)} has succeeded. */
    static boolean isAuthorized() { return sAuthorized; }

    /** Read-only view of the current denial reason (for debugging). */
    static String denialReason() { return sReason; }

    /** Throws {@link SecurityException} if not authorized. Called by FFmpegKit. */
    static void check() {
        if (!sAuthorized) {
            throw new SecurityException(
                "com.faj.ffmpeg: not authorized — " + sReason
                + ". Call FFmpegLicense.authorize(context) from "
                + "Application.onCreate before using FFmpegKit.");
        }
    }

    // ------------------------------------------------------------------
    // Package-private hooks for FFmpegRemoteLicense (cloud kill-switch).
    // ------------------------------------------------------------------
    static synchronized void grant() {
        sAuthorized = true;
        sReason = null;
    }

    static synchronized void revoke(String reason) {
        sAuthorized = false;
        sReason = reason;
    }
}


