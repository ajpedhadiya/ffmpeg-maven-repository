package com.faj.ffmpeg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Process-wide FFmpegKit configuration: session registry, log/statistics
 * dispatch, default callbacks, and the single-threaded native dispatcher.
 *
 * <p>Mirrors the role of {@code com.arthenica.ffmpegkit.FFmpegKitConfig} in
 * the reference library. Most apps will only touch
 * {@link #enableLogCallback(LogCallback)} and
 * {@link #enableStatisticsCallback(StatisticsCallback)}.</p>
 */
public final class FFmpegKitConfig {

    private static final Object LOCK = new Object();
    private static final Map<Long, FFmpegSession> SESSIONS = Collections.synchronizedMap(new LinkedHashMap<>());

    private static volatile LogCallback        globalLogCallback;
    private static volatile StatisticsCallback globalStatisticsCallback;
    private static volatile Level              activeLogLevel = Level.AV_LOG_INFO;
    private static volatile boolean            logsToFile = true;

    private static final ExecutorService ASYNC_EXECUTOR = Executors.newCachedThreadPool(new ThreadFactory() {
        private final AtomicInteger n = new AtomicInteger(1);
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "ffmpeg-kit-async-" + n.getAndIncrement());
            t.setDaemon(true);
            return t;
        }
    });

    private FFmpegKitConfig() {}

    // ---- public API -------------------------------------------------------

    public static void enableLogCallback(LogCallback cb) { globalLogCallback = cb; }
    public static void enableStatisticsCallback(StatisticsCallback cb) { globalStatisticsCallback = cb; }

    public static Level getLogLevel() { return activeLogLevel; }
    public static void  setLogLevel(Level level) {
        activeLogLevel = level == null ? Level.AV_LOG_INFO : level;
        FFmpegKit.load();
        nativeSetLogLevel(activeLogLevel.getValue());
    }

    /** @return all sessions still tracked, oldest first. */
    public static List<FFmpegSession> getSessions() {
        synchronized (SESSIONS) { return new ArrayList<>(SESSIONS.values()); }
    }

    public static FFmpegSession getSession(long id) { return SESSIONS.get(id); }
    public static void clearSessions() { SESSIONS.clear(); }

    // ---- internal: invoked by FFmpegKit ----------------------------------

    static void registerSession(FFmpegSession s) { SESSIONS.put(s.getSessionId(), s); }

    static ExecutorService asyncExecutor() { return ASYNC_EXECUTOR; }

    // ---- callbacks invoked from JNI on the native execution thread -------
    //
    // These are static so the native side can resolve them with one
    // GetStaticMethodID per callback at load time. They never throw.

    @SuppressWarnings("unused") // called from JNI
    static void nativeLogCallback(long sessionId, int level, String message) {
        FFmpegSession s = SESSIONS.get(sessionId);
        Log log = new Log(sessionId, level, message);
        if (s != null) {
            s.appendLog(log);
            try { if (s.logCallback != null) s.logCallback.apply(log); } catch (Throwable ignored) {}
        }
        try {
            LogCallback g = globalLogCallback;
            if (g != null) g.apply(log);
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings("unused") // called from JNI
    static void nativeStatisticsCallback(long sessionId, int videoFrameNumber,
                                         float videoFps, float videoQuality,
                                         long size, int time,
                                         double bitrate, double speed) {
        Statistics stats = new Statistics(sessionId, videoFrameNumber, videoFps,
                videoQuality, size, time, bitrate, speed);
        FFmpegSession s = SESSIONS.get(sessionId);
        if (s != null) {
            s.updateStatistics(stats);
            try { if (s.statisticsCallback != null) s.statisticsCallback.apply(stats); } catch (Throwable ignored) {}
        }
        try {
            StatisticsCallback g = globalStatisticsCallback;
            if (g != null) g.apply(stats);
        } catch (Throwable ignored) {}
    }

    static int runSession(FFmpegSession session) {
        registerSession(session);
        session.onStart();
        int rc;
        try {
            synchronized (LOCK) { // fftools is not re-entrant
                rc = nativeFFmpegExecute(session.getSessionId(), session.getArguments());
            }
            session.onComplete(rc);
        } catch (Throwable t) {
            session.onFail(t);
            rc = -1;
        }
        try {
            if (session.completeCallback != null) session.completeCallback.apply(session);
        } catch (Throwable ignored) {}
        return rc;
    }

    // Native bridge declared on the same class the JNI lookup expects.
    static native int  nativeFFmpegExecute(long sessionId, String[] arguments);
    static native void nativeFFmpegCancel(long sessionId);
    static native void nativeSetLogLevel(int level);
}
