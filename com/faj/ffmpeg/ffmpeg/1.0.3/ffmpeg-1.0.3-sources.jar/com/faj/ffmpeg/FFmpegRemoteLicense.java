package com.faj.ffmpeg;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Cloud kill-switch for {@link FFmpegLicense}.
 *
 * <p>The library hits a hosted JSON file at {@link #CONFIG_URL} on every
 * call to {@link #authorize(Context)}. The result decides whether
 * {@link FFmpegKit} calls are allowed:</p>
 *
 * <pre>{@code
 * {
 *   "version": 1,
 *   "allowed": ["com.pik.roxstar", "com.softek.fffmpegtest"],
 *   "blocked": ["com.bad.fork"]
 * }
 * }</pre>
 *
 * <p>Behavior:
 * <ul>
 *   <li>Cached config is applied instantly (so offline launches still work).</li>
 *   <li>Fresh config is fetched in the background; verdict updates as soon
 *       as the response arrives (usually &lt; 1 s).</li>
 *   <li>If the package is in {@code blocked} → revoked even if it's also
 *       in {@code allowed}.</li>
 *   <li>If {@code allowed} is non-empty and the package isn't in it → revoked.</li>
 *   <li>If both lists are empty/missing → falls back to the hardcoded
 *       {@link FFmpegLicense} allow-list.</li>
 *   <li>If the network call fails and there's no cache → also falls back
 *       to the hardcoded list.</li>
 * </ul>
 *
 * <p><b>Manifest:</b> the consuming app needs
 * {@code <uses-permission android:name="android.permission.INTERNET"/>}
 * (already required by most apps).</p>
 */
public final class FFmpegRemoteLicense {

    /**
     * Public URL of the cloud kill-switch JSON. To rotate it: edit this
     * constant and rebuild the AAR. The repo hosting it must stay public.
     */
    public static final String CONFIG_URL =
            "https://raw.githubusercontent.com/ajpedhadiya/ffmpeg-maven-repository/main/config.json";

    private static final String TAG = "FFmpegLicense";
    private static final String PREFS = "com.faj.ffmpeg.license";
    private static final String K_LAST_JSON = "last_json";
    private static final String K_LAST_TS   = "last_ts";

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private FFmpegRemoteLicense() {}

    /**
     * Verify against the hosted allow/block-list. Returns immediately;
     * the network fetch happens on a background thread. Use the same
     * call site as {@link FFmpegLicense#authorize(Context)} — this
     * supersedes that one.
     */
    public static void authorize(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        final String pkg = app.getPackageName();

        // 1. Apply cached verdict immediately. If there is no cache, fall
        //    back to the hardcoded list so the very first launch on a
        //    device still has *some* answer before the network responds.
        if (!applyCached(app, pkg)) {
            FFmpegLicense.authorize(app);
        }

        // 2. Refresh from the cloud; update the verdict on response.
        IO.submit(() -> refresh(app, pkg));
    }

    // ------------------------------------------------------------------

    private static boolean applyCached(Context app, String pkg) {
        SharedPreferences sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(K_LAST_JSON, null);
        if (json == null) return false;
        try {
            return applyJson(pkg, new JSONObject(json), "cache");
        } catch (Exception e) {
            return false;
        }
    }

    private static void refresh(Context app, String pkg) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(CONFIG_URL).openConnection();
            conn.setConnectTimeout(5_000);
            conn.setReadTimeout(5_000);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Cache-Control", "no-cache");
            int code = conn.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "license fetch HTTP " + code);
                return;
            }
            StringBuilder body = new StringBuilder();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) body.append(line);
            }
            String json = body.toString();
            JSONObject obj = new JSONObject(json);

            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(K_LAST_JSON, json)
                    .putLong(K_LAST_TS, System.currentTimeMillis())
                    .apply();

            applyJson(pkg, obj, "remote");
        } catch (Exception e) {
            Log.w(TAG, "license fetch failed: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static boolean applyJson(String pkg, JSONObject obj, String src) {
        Set<String> blocked = toSet(obj.optJSONArray("blocked"));
        Set<String> allowed = toSet(obj.optJSONArray("allowed"));

        if (blocked.contains(pkg)) {
            FFmpegLicense.revoke("revoked by " + src + " (package blocked)");
            Log.w(TAG, "REVOKED via " + src + ": " + pkg);
            return true;
        }
        if (!allowed.isEmpty()) {
            if (allowed.contains(pkg)) {
                FFmpegLicense.grant();
                Log.i(TAG, "AUTHORIZED via " + src + ": " + pkg);
                return true;
            } else {
                FFmpegLicense.revoke("revoked by " + src + " (package not in allow-list)");
                Log.w(TAG, "REVOKED via " + src + ": " + pkg + " not in allow-list");
                return true;
            }
        }
        return false;
    }

    private static Set<String> toSet(JSONArray arr) {
        Set<String> s = new HashSet<>();
        if (arr == null) return s;
        for (int i = 0; i < arr.length(); i++) {
            String v = arr.optString(i, null);
            if (v != null && !v.isEmpty()) s.add(v);
        }
        return s;
    }
}

