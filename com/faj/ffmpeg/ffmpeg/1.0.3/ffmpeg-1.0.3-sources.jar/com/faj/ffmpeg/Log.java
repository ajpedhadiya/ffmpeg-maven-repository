package com.faj.ffmpeg;

/** A single line of FFmpeg log output, tagged with its severity. */
public final class Log {
    private final long sessionId;
    private final Level level;
    private final String message;

    public Log(long sessionId, int level, String message) {
        this.sessionId = sessionId;
        this.level = Level.from(level);
        this.message = message == null ? "" : message;
    }

    public long getSessionId() { return sessionId; }
    public Level getLevel() { return level; }
    public String getMessage() { return message; }

    @Override public String toString() { return message; }
}
