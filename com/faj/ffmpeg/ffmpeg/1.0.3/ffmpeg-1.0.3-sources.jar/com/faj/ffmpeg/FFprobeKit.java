package com.faj.ffmpeg;

import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Tiny convenience wrapper around Android's {@link MediaExtractor} that
 * gives ffprobe-style metadata without invoking FFmpeg. For full FFmpeg
 * probing (codec params, side data, HDR metadata, etc.) call
 * {@link FFmpegKit#executeWithArguments} with ffprobe-style arguments
 * once the patched fftools/ffprobe entry point is wired in.
 */
public final class FFprobeKit {

    public static final class StreamInfo {
        public final int    index;
        public final String mime;
        public final long   durationUs;
        public final int    width;       // -1 if not video
        public final int    height;      // -1 if not video
        public final int    sampleRate;  // -1 if not audio
        public final int    channelCount;// -1 if not audio
        public final int    bitrate;     // -1 if unknown

        StreamInfo(int idx, MediaFormat f) {
            this.index = idx;
            this.mime = f.getString(MediaFormat.KEY_MIME);
            this.durationUs = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) : -1L;
            this.width  = f.containsKey(MediaFormat.KEY_WIDTH)  ? f.getInteger(MediaFormat.KEY_WIDTH)  : -1;
            this.height = f.containsKey(MediaFormat.KEY_HEIGHT) ? f.getInteger(MediaFormat.KEY_HEIGHT) : -1;
            this.sampleRate   = f.containsKey(MediaFormat.KEY_SAMPLE_RATE)   ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE)   : -1;
            this.channelCount = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : -1;
            this.bitrate = f.containsKey(MediaFormat.KEY_BIT_RATE) ? f.getInteger(MediaFormat.KEY_BIT_RATE) : -1;
        }

        @Override public String toString() {
            return "Stream{" + index + ", mime=" + mime
                + ", " + (width > 0 ? width + "x" + height : "")
                + (sampleRate > 0 ? " " + sampleRate + "Hz x" + channelCount + "ch" : "")
                + ", durUs=" + durationUs + "}";
        }
    }

    public static final class MediaInformation {
        public final String path;
        public final List<StreamInfo> streams;
        public final long totalDurationUs;

        MediaInformation(String path, List<StreamInfo> streams) {
            this.path = path;
            this.streams = streams;
            long max = 0;
            for (StreamInfo s : streams) if (s.durationUs > max) max = s.durationUs;
            this.totalDurationUs = max;
        }
    }

    private FFprobeKit() {}

    /**
     * Probe a local file path. Returns {@code null} on I/O error.
     */
    public static MediaInformation getMediaInformation(String path) {
        FFmpegLicense.check();
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(path);
            int n = ex.getTrackCount();
            List<StreamInfo> streams = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                streams.add(new StreamInfo(i, ex.getTrackFormat(i)));
            }
            return new MediaInformation(path, streams);
        } catch (IOException e) {
            return null;
        } finally {
            ex.release();
        }
    }
}
